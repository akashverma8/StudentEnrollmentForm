function validateData() {
  var empIdVar = $("#empDate").val();
  if (empIdVar === "") {
    alert("Enrollment Date is a Required Value");
    $("#empDate").focus();
    return null;
  }

  var empNameVar = $("#empName").val();
  if (empNameVar === "") {
    alert("Full Name is a Required Value");
    $("#empName").focus();
    return null;
  }

  var empEmailVar = $("#empEmail").val();
  if (empEmailVar === "") {
    alert("Email is a Required Value");
    $("#empEmail").focus();
    return null;
  }

  var empRollVar = $("#empRoll").val();
  if (empRollVar === "") {
    alert("Roll Number is a Required Value");
    $("#empRoll").focus();
    return null;
  }

  var empAddressVar = $("#empAddress").val();
  if (empAddressVar === "") {
    alert("Address is a Required Value");
    $("#empAddress").focus();
    return null;
  }

  var empClassVar = $("#empClass").val();
  if (empClassVar === "") {
    alert("Student Class is a Required Value");
    $("#empClass").focus();
    return null;
  }

  var jsonStrObj = {
    empDate: empIdVar,
    empName: empNameVar,
    empEmail: empEmailVar,
    empRoll: empRollVar,
    empAddress: empAddressVar,
    empClass: empClassVar
  };

  return JSON.stringify(jsonStrObj);
}

function getEmp() {
  var empIdJsonObj = getEmpIdAsJsonObj();
  var getRequest = createGET_BY_KEYRequest("90931365|-31949321326994253|90950222", "Student", "EMP_REL", empIdJsonObj);
  jQuery.ajaxSetup({ async: false });
  var resJsonObj = executeCommandAtGivenBaseUrl(getRequest, "http://api.login2explore.com:5577", "/api/iml");
  jQuery.ajaxSetup({ async: true });

  if (resJsonObj.status === 400) {
    $("#save").prop("disabled", false);
    $("#reset").prop("disabled", false);
    $("#empName").focus();
  } else if (resJsonObj.status === 200) {
    $("#empId").prop("disabled", true);
    fillData(resJsonObj);
    $("#update").prop("disabled", false);
    $("#reset").prop("disabled", false);
    $("#empName").focus();
  }
}

function resetForm() {
  $("#empId").val("");
  $("#empName").val("");
  $("#empEmail").val("");
  $("#empRoll").val("");
  $("#empAddress").val("");
  $("#empClass").val("");
  $("#empId").prop("disabled", false);
  $("#save").prop("disabled", true);
  $("#update").prop("disabled", true);
  $("#reset").prop("disabled", true);
  $("#empId").focus();
}

function saveData() {
  var jsonStrObj = validateData();
  if (!jsonStrObj) {
    return;
  }

  var putReqStr = createPUTRequest("90931365|-31949321326994253|90950222", jsonStrObj, "Student", "EMP_REL");
  jQuery.ajaxSetup({ async: false });
  var resultObj = executeCommandAtGivenBaseUrl(putReqStr, "http://api.login2explore.com:5577", "/api/iml");
  jQuery.ajaxSetup({ async: true });

  alert(JSON.stringify(resultObj));
  resetForm();
}

function updateData() {
  var jsonChg = validateData();
  if (!jsonChg) {
    return;
  }

  var updateRequest = createUPDATERecordRequest("90931365|-31949321326994253|90950222", jsonChg, "Student", "EMP_REL", localStorage.getItem(""));
  jQuery.ajaxSetup({ async: false });
  var resJsonObj = executeCommandAtGivenBaseUrl(updateRequest, "http://api.login2explore.com:5577", "/api/iml");
  jQuery.ajaxSetup({ async: true });

  console.log(resJsonObj);
  resetForm();
}

function getEmpIdAsJsonObj() {
  var empId = $('#empId').val();
  var jsonStr = {
    id: empId
  };
  return JSON.stringify(jsonStr);
}




